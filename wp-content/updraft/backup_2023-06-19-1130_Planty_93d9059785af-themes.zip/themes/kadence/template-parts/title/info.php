<?php
/**
 * Template part for displaying a post's metadata
 *
 * @package kadence
 */

namespace Kadence;

do_action( 'kadence_single_title_info_area' );
