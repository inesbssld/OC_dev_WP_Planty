<?php

return [
	'title' => __( 'System Tweaks', 'better-wp-security' ),
];
