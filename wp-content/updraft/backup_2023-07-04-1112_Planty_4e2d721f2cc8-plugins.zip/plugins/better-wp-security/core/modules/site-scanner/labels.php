<?php

return [
	'title' => __( 'Site Scanner', 'better-wp-security' ),
];
