<?php

require_once __DIR__ . '/class-itsec-system-tweaks.php';

ITSEC_System_Tweaks::activate();
