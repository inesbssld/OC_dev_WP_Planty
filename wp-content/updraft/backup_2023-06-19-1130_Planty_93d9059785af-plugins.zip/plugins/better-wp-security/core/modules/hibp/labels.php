<?php

return [
	'title' => __( 'Have I Been Pwned', 'better-wp-security' ),
];
