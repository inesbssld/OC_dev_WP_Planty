import store from './store';

export { store };
