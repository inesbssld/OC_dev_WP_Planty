/**
 * Internal dependencies
 */
import './style.scss';

export default function App() {
	return null;
}
