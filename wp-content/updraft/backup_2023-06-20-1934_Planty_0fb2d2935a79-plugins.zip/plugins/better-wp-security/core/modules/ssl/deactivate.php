<?php

require_once( __DIR__ . '/class-itsec-ssl.php' );
ITSEC_SSL::deactivate();
