<?php

ITSEC_Modules::set_setting( 'global', 'proxy', 'automatic' );
