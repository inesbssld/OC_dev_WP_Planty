<?php

return [
	'title' => __( 'User Groups', 'better-wp-security' ),
];
