<?php

return [
	'title' => __( 'File Permissions', 'better-wp-security' ),
];
