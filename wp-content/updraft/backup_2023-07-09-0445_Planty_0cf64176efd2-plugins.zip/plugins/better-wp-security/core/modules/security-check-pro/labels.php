<?php

return [
	'title' => __( 'Security Check Pro', 'better-wp-security' ),
];
