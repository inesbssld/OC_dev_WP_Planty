<?php

namespace iThemesSecurity\User_Groups;

use iThemesSecurity\Exception\Exception;

final class Matchable_Not_Found extends \OutOfBoundsException implements Exception {

}
