<?php

namespace iThemesSecurity\User_Groups\Repository;

use iThemesSecurity\Exception\Exception;

final class User_Group_Not_Found extends \OutOfBoundsException implements Exception {

}
