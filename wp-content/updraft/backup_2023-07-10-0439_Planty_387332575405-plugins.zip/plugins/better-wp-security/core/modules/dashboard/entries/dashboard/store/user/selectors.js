export function getPrimaryDashboard( state ) {
	return state.user.primaryDashboard;
}
