/**
 * Internal dependencies
 */
import { GroupNav } from '../';

export default function Layout() {
	return <GroupNav />;
}
